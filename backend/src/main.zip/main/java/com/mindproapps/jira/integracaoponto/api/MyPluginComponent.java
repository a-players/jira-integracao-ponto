package com.mindproapps.jira.integracaoponto.api;
 
public interface MyPluginComponent
{
    String getName();
}