package com.mindproapps.jira.integracaoponto.model.timesheets;

public enum TimesheetAction {
    APPROVE,
    REJECT,
    REOPEN,
    SUBMIT
}
