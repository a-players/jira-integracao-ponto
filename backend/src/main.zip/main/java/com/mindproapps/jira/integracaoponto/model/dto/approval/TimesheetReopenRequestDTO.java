package com.mindproapps.jira.integracaoponto.model.dto.approval;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimesheetReopenRequestDTO {
    private String reason;
}
